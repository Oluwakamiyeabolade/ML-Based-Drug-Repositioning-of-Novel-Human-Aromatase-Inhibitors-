# Data

## aromatase_inhibitors.csv
Reference library of known aromatase inhibitors with experimental pIC50 values sourced from ChEMBL. Required columns: `Smiles`, `pChEMBL Value`.

## chembl_22_clean_1576904_sorted_std_final.smi
A standardized SMILES file of ~1.5 million small molecules from ChEMBL 22.  
**Not included in this repository due to file size.**

Download from: https://www.ebi.ac.uk/chembl/

Expected format (tab-separated, no header):
```
SMILES	CHEMBL_ID
CC(=O)Nc1ccc(O)cc1	CHEMBL112
...
```
